import 'package:flutter/material.dart';

var primaryColor =const Color.fromARGB(255, 138, 60, 55);
var secondaryColor = const Color.fromARGB(212, 135, 81, 77);